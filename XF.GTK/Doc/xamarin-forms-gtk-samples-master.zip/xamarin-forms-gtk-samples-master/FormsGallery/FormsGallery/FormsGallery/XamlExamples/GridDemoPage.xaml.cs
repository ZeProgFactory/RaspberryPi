﻿using System;
using Xamarin.Forms;

namespace FormsGallery.XamlExamples
{
    public partial class GridDemoPage : ContentPage
    {
        public GridDemoPage()
        {
            InitializeComponent();
        }
    }
}