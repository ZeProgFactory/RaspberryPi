﻿using System;
using Xamarin.Forms;

namespace FormsGallery.XamlExamples
{
    public partial class TabbedPageDemoPage : TabbedPage
    {
        public TabbedPageDemoPage()
        {
            InitializeComponent();
        }
    }
}