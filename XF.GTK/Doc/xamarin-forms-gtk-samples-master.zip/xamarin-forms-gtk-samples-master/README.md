# Xamarin.Forms GTK Samples

This repository contains the samples from [Xamarin.Forms samples repository](https://github.com/xamarin/xamarin-forms-samples). You will find GTK versions of original sample apps here. Visit the [Xamarin.Forms Samples Gallery](https://developer.xamarin.com/samples/xamarin-forms/Xamarin.Forms/) for their description.

For Xamarin.Forms related matters use [Xamarin.Forms issue tracker](https://github.com/xamarin/xamarin-forms-samples/issues).

## Samples Submission Guidelines

Please follow the [Submission Guidelines of the original repository](https://github.com/xamarin/xamarin-forms-samples#samples-submission-guidelines).