﻿using System;
using Xamarin.Forms;

namespace FormsGallery.XamlExamples
{
    public partial class TextCellDemoPage : ContentPage
    {
        public TextCellDemoPage()
        {
            InitializeComponent();
        }
    }
}