﻿﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;

namespace WorkingWithImages
{	
	public partial class DownloadImagesXaml : ContentPage
	{	
		public DownloadImagesXaml ()
		{
			InitializeComponent ();
		}
	}
}

