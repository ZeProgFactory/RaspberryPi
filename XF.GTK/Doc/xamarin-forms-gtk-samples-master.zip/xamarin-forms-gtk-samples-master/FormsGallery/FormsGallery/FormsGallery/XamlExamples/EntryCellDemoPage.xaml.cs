﻿using System;
using Xamarin.Forms;

namespace FormsGallery.XamlExamples
{
    public partial class EntryCellDemoPage : ContentPage
    {
        public EntryCellDemoPage()
        {
            InitializeComponent();
        }
    }
}