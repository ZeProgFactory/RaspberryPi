ListView Colors
======

A `ListView` displaying the system colors, each of which is illustrated with a `BoxView`.

This sample is described in more detail in the article on [BoxView](/guides/xamarin-forms/user-interface/boxview/).

Author
------

Charles Petzold
