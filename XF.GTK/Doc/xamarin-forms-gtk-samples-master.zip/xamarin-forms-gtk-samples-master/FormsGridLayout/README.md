GridLayoutDemo
==========
	
This sample demonstrates how to display various ui elements in a grid.

GridLayoutDemo is based off of https://github.com/xamarin/monodroid-samples/tree/master/GridLayoutDemo
	
Author
------
Peter Collins