﻿using System;
using Xamarin.Forms;

namespace FormsGallery.XamlExamples
{
    public partial class ActivityIndicatorDemoPage : ContentPage
    {
        public ActivityIndicatorDemoPage()
        {
            InitializeComponent();
        }
    }
}