﻿using System;
using Xamarin.Forms;

namespace FormsGallery.XamlExamples
{
    public partial class TableViewFormDemoPage : ContentPage
    {
        public TableViewFormDemoPage()
        {
            InitializeComponent();
        }
    }
}