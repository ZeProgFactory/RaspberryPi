Working with Fonts
==============

These samples relate to the [Working with Fonts in Xamarin.Forms](http://developer.xamarin.com/guides/cross-platform/xamarin-forms/working-with/fonts/) doc.

![screenshot](https://raw.githubusercontent.com/xamarin/xamarin-forms-samples/master/WorkingWithFonts/Screenshots/custom-sml.png "Fonts")

Author
------

Craig Dunn
