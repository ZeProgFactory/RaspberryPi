﻿﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;

namespace WorkingWithColors
{	
	public partial class ColorsInXaml : ContentPage
	{	
		public ColorsInXaml ()
		{
			InitializeComponent ();
		}
	}
}

