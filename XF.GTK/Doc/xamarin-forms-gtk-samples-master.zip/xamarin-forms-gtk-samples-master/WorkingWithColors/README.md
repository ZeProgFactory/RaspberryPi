Working with Colors
==============

These samples relate to the [Working with Colors in Xamarin.Forms](http://developer.xamarin.com/guides/cross-platform/xamarin-forms/working-with/colors/) doc.

![screenshot](https://raw.githubusercontent.com/xamarin/xamarin-forms-samples/master/WorkingWithColors/Screenshots/Colors-sml.png "Colors")

Author
------

Craig Dunn
