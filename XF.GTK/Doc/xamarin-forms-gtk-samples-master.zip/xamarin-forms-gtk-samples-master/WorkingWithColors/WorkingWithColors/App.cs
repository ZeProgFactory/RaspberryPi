﻿using System;
using Xamarin.Forms;

namespace WorkingWithColors
{
	public class App : Application
	{
		public App ()
		{	
			MainPage = new ColorDemo ();

//			MainPage = new ColorsInXaml ();

		}
	}
}

