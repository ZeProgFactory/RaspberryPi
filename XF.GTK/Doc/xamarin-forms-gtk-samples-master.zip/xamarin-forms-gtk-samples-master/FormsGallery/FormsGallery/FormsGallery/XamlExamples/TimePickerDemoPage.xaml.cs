﻿using System;
using Xamarin.Forms;

namespace FormsGallery.XamlExamples
{
    public partial class TimePickerDemoPage : ContentPage
    {
        public TimePickerDemoPage()
        {
            InitializeComponent();
        }
    }
}