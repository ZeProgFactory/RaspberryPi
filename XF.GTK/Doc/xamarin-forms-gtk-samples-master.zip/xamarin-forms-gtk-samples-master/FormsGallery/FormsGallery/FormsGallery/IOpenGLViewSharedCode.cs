﻿using System;
using Xamarin.Forms;

namespace FormsGallery
{
    public interface IOpenGLViewSharedCode
    {
        void RenderLoop(Rectangle rect);
    }
}
