﻿using System;
using Xamarin.Forms;

namespace FormsGallery.XamlExamples
{
    public partial class ContentPageDemoPage : ContentPage
    {
        public ContentPageDemoPage()
        {
            InitializeComponent();
        }
    }
}