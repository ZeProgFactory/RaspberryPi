﻿using System;
using Xamarin.Forms;

namespace FormsGallery.XamlExamples
{
    public partial class ImageDemoPage : ContentPage
    {
        public ImageDemoPage()
        {
            InitializeComponent();
        }
    }
}