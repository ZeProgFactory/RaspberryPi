﻿using System;
using Xamarin.Forms;

namespace FormsGallery.XamlExamples
{
    public partial class FrameDemoPage : ContentPage
    {
        public FrameDemoPage()
        {
            InitializeComponent();
        }
    }
}