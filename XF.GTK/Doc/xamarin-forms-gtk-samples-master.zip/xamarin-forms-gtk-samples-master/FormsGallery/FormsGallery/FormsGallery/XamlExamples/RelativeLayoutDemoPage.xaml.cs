﻿using System;
using Xamarin.Forms;

namespace FormsGallery.XamlExamples
{
    public partial class RelativeLayoutDemoPage : ContentPage
    {
        public RelativeLayoutDemoPage()
        {
            InitializeComponent();
        }
    }
}