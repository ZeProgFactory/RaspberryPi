FormsGallery
============

This program displays all the views, cells, layouts, and pages available in Xamarin.Forms, 
one per page.


Author
------

Charles Petzold
