﻿using System;
using Xamarin.Forms;

namespace FormsGallery.XamlExamples
{
    public partial class WebViewDemoPage : ContentPage
    {
        public WebViewDemoPage()
        {
            InitializeComponent();
        }
    }
}