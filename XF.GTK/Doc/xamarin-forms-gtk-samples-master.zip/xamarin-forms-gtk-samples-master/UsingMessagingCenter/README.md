Xamarin.Forms MessagingCenter
==============

Sample code for the [Xamarin.Forms MessagingCenter](http://developer.xamarin.com/guides/cross-platform/xamarin-forms/messaging-center) doc.


Author
------

Craig Dunn
