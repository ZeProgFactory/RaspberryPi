ClassHierarchy
==============

This program uses .NET reflection to display a scrollable hierarchy of all Xamarin.Forms classes, structures, and enumerations.
Non-instantiable classes are displayed in the system accent color.

ClassHierarchy is a handy reference for Xamarin.Forms developers, as well as demonstrating using 
the StackLayout and ScrollView from code.

Author
------

Charles Petzold
