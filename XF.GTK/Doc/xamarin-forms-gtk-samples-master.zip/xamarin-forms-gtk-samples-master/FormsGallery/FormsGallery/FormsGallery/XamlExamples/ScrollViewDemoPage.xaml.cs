﻿using System;
using Xamarin.Forms;

namespace FormsGallery.XamlExamples
{
    public partial class ScrollViewDemoPage : ContentPage
    {
        public ScrollViewDemoPage()
        {
            InitializeComponent();
        }
    }
}