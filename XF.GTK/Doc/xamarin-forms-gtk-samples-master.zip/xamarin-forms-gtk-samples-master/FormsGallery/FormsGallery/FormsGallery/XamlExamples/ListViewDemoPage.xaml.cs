﻿using System;
using Xamarin.Forms;

namespace FormsGallery.XamlExamples
{
    public partial class ListViewDemoPage : ContentPage
    {
        public ListViewDemoPage()
        {
            InitializeComponent();
        }
    }
}