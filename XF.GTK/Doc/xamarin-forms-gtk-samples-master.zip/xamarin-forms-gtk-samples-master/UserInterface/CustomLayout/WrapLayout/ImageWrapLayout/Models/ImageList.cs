﻿using System.Collections.Generic;

namespace ImageWrapLayout
{
	class ImageList
	{
		public List<string> Photos = null;
	}
}
