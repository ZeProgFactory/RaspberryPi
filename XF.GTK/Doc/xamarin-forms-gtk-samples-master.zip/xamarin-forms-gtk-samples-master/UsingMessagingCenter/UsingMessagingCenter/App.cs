﻿using System;
using Xamarin.Forms;

namespace UsingMessagingCenter
{
	public class App : Application
	{
		public App()
		{	
			MainPage = new MainPage ();
		}
	}
}

