﻿using System;
using Xamarin.Forms;

namespace FormsGallery.XamlExamples
{
    public partial class StepperDemoPage : ContentPage
    {
        public StepperDemoPage()
        {
            InitializeComponent();
        }
    }
}