﻿using System;
using Xamarin.Forms;

namespace FormsGallery.XamlExamples
{
    public partial class SwitchDemoPage : ContentPage
    {
        public SwitchDemoPage()
        {
            InitializeComponent();
        }
    }
}