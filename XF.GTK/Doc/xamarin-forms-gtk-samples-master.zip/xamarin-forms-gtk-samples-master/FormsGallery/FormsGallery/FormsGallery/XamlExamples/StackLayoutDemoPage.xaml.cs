﻿using System;
using Xamarin.Forms;

namespace FormsGallery.XamlExamples
{
    public partial class StackLayoutDemoPage : ContentPage
    {
        public StackLayoutDemoPage()
        {
            InitializeComponent();
        }
    }
}