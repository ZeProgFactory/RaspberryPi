Working with Platform Tweaks
==============

This samples demonstrates how to use the `Device` class. For more information, see the [Device Class](http://developer.xamarin.com/guides/xamarin-forms/platform-features/device/).


Author
------

Craig Dunn
