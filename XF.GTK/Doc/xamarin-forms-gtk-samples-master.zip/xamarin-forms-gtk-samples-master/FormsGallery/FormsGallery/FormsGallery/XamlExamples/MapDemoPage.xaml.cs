﻿using System;
using Xamarin.Forms;

namespace FormsGallery.XamlExamples
{
    public partial class MapDemoPage : ContentPage
    {
        public MapDemoPage()
        {
            InitializeComponent();
        }
    }
}