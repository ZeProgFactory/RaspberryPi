﻿using System;
using Xamarin.Forms;

namespace FormsGallery.XamlExamples
{
    public partial class CarouselPageDemoPage : CarouselPage
    {
        public CarouselPageDemoPage()
        {
            InitializeComponent();
        }
    }
}